# FS-Task-

# For Any Doubt 💬

Reach out to *Naman* at *9149005205* Or *Parth* at *9559805577*.

## Week-1 Project Overview
Key Features: The initial version should include the following: <br>
o	Feature 1: e.g., Home screen for your class timetable ( Using outlines atleast 2 teachers and subjects ) <br>
o	Feature 2: e.g., Other pages like Contact Teacher and details of teacher on clicking the cell ( A new page must open ) <br>
o	Feature 3: e.g., Improve UI and add ui interactions like hover, click etc <br>
Tech Stack and Tools
•	Front-End: Html/Css/Bootstrap/JS, etc.

![image](https://github.com/user-attachments/assets/51ed2eea-253a-436a-b37a-25988ab6081f)
